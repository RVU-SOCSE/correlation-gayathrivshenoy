# PROGRAM - 16 (B)
# Scatter Plot using Matplotlib and Seaborn

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read CSV
df = pd.read_csv("C:/Users/HP/Desktop/PYTHON/exp.csv")

# -------- Matplotlib Scatter Plot --------
plt.figure()
plt.scatter(df['YearsExperience'], df['salary'])
plt.title("Experience vs salary (Matplotlib)")
plt.xlabel("Years of Experience")
plt.ylabel("salary")
plt.grid()
plt.show()

# -------- Seaborn Scatter Plot --------
plt.figure()
sns.scatterplot(x='YearsExperience', y='salary', data=df)
plt.title("Experience vs salary (Seaborn)")
plt.show()
