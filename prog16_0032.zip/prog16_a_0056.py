# PROGRAM - 16 (A)
# Line Chart using Matplotlib and Seaborn

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read CSV
df = pd.read_csv("C:/Users/HP/Desktop/PYTHON/exp.csv")

# -------- Matplotlib Line Plot --------
plt.figure()
plt.plot(df['YearsExperience'], df['salary'], marker='o')
plt.title("salary Trend with Experience (Matplotlib)")
plt.xlabel("Years of Experience")
plt.ylabel("salary")
plt.grid()
plt.show()

# -------- Seaborn Line Plot --------
plt.figure()
sns.lineplot(x='YearsExperience', y='salary', data=df)
plt.title("salary Trend with Experience (Seaborn)")
plt.show()
